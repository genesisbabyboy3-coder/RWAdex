# Discord Card Catcher Bot

A starter Discord bot for a command-based card-catching game. Members use `/catch` to receive a random card, `/collection` to view cards they own, and `/cards` to browse the catalog. Server admins can use `/addcard` to add more cards.

## Included starter cards

The project includes the 10 card images shared in the chat. A few visible card labels were readable (LIGHTING, PR STRIKER, SMACKDOWN, RAGE); where the exact title was unclear, the card is given a numbered placeholder name so you can rename it later.

## 1. Create your Discord application

1. Open the Discord Developer Portal: https://discord.com/developers/applications
2. Create an application, then open its **Bot** page and add a bot.
3. Copy the bot token. Keep it private; never post it in chat or commit it to GitHub.
4. Under **Installation** (or OAuth2 URL Generator), enable the `bot` and `applications.commands` scopes.
5. Give it permissions to **Send Messages**, **Embed Links**, and **Attach Files**. Invite it to your server.

## 2. Run the bot

Python 3.10 or newer is recommended.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

Copy `.env.example` to `.env`, then put your token in `DISCORD_TOKEN`.

For quick command updates while testing, put your server ID in `GUILD_ID`. Leave it blank for global commands (which can take longer to appear).

```bash
python bot.py
```

## Commands

- `/catch` — catch one random card (30-second per-user cooldown).
- `/collection` — show your collection; optionally choose another member.
- `/cards` — browse the card catalog.
- `/addcard name rarity image_url` — add a card. Requires **Manage Server**. `image_url` is optional and should be a direct, publicly accessible image URL.

## Add or rename bundled cards

Edit `cards.json` before the first run to change the starter names. The bundled images are in `cards/`. Existing card IDs already saved in `cards.db` are not overwritten on later starts, so use `/addcard` for new entries or edit the database if you need to rename a card after it has already been initialized.

The database file `cards.db` is created automatically and stores card definitions, collections, and cooldowns. Back it up to preserve players' collections.
