import json
import os
import random
import sqlite3
import time
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

BASE_DIR = Path(__file__).parent
DB_PATH = BASE_DIR / "cards.db"
CATALOG_PATH = BASE_DIR / "cards.json"
COOLDOWN_SECONDS = 30
RARITY_WEIGHT = {"Common": 65, "Rare": 25, "Epic": 9, "Legendary": 1}

load_dotenv(BASE_DIR / ".env")
TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = os.getenv("GUILD_ID", "").strip()


def connect_db():
    con = sqlite3.connect(DB_PATH)
    con.execute("""CREATE TABLE IF NOT EXISTS collection (
        user_id TEXT NOT NULL,
        card_id TEXT NOT NULL,
        quantity INTEGER NOT NULL DEFAULT 1,
        PRIMARY KEY (user_id, card_id)
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS cards (
        card_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        rarity TEXT NOT NULL,
        image TEXT
    )""")
    con.execute("CREATE TABLE IF NOT EXISTS cooldowns (user_id TEXT PRIMARY KEY, last_catch REAL NOT NULL)")
    con.commit()
    return con


def load_catalog():
    catalog = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    with connect_db() as con:
        for card in catalog:
            con.execute(
                "INSERT OR IGNORE INTO cards(card_id,name,rarity,image) VALUES(?,?,?,?)",
                (card["id"], card["name"], card["rarity"], card.get("image")),
            )
    return catalog


intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)


def get_cards():
    with connect_db() as con:
        rows = con.execute("SELECT card_id,name,rarity,image FROM cards ORDER BY name COLLATE NOCASE").fetchall()
    return [{"id": r[0], "name": r[1], "rarity": r[2], "image": r[3]} for r in rows]


def get_card(card_id):
    with connect_db() as con:
        row = con.execute("SELECT card_id,name,rarity,image FROM cards WHERE card_id=?", (card_id,)).fetchone()
    return {"id": row[0], "name": row[1], "rarity": row[2], "image": row[3]} if row else None


@bot.event
async def on_ready():
    if GUILD_ID.isdigit():
        guild = discord.Object(id=int(GUILD_ID))
        bot.tree.copy_global_to(guild=guild)
        await bot.tree.sync(guild=guild)
        print(f"Synced commands to test server {GUILD_ID}")
    else:
        await bot.tree.sync()
        print("Synced global slash commands (may take a little while to appear).")
    print(f"Logged in as {bot.user}")


@bot.tree.command(name="catch", description="Catch a random card!")
async def catch(interaction: discord.Interaction):
    now = time.time()
    with connect_db() as con:
        row = con.execute("SELECT last_catch FROM cooldowns WHERE user_id=?", (str(interaction.user.id),)).fetchone()
        if row and now - row[0] < COOLDOWN_SECONDS:
            left = int(COOLDOWN_SECONDS - (now - row[0])) + 1
            await interaction.response.send_message(f"Your next catch is ready in **{left}s**.", ephemeral=True)
            return
        con.execute("INSERT OR REPLACE INTO cooldowns(user_id,last_catch) VALUES(?,?)", (str(interaction.user.id), now))

    cards = get_cards()
    if not cards:
        await interaction.response.send_message("There are no cards in the catalog yet.", ephemeral=True)
        return
    weights = [RARITY_WEIGHT.get(c["rarity"], 1) for c in cards]
    card = random.choices(cards, weights=weights, k=1)[0]
    with connect_db() as con:
        con.execute("""INSERT INTO collection(user_id,card_id,quantity) VALUES(?,?,1)
            ON CONFLICT(user_id,card_id) DO UPDATE SET quantity=quantity+1""",
            (str(interaction.user.id), card["id"]))
        quantity = con.execute("SELECT quantity FROM collection WHERE user_id=? AND card_id=?",
                               (str(interaction.user.id), card["id"])).fetchone()[0]

    embed = discord.Embed(title=f"🎴 You caught: {card['name']}", color=discord.Color.gold())
    embed.add_field(name="Rarity", value=card["rarity"], inline=True)
    embed.add_field(name="Copies owned", value=str(quantity), inline=True)
    image_path = BASE_DIR / card["image"] if card.get("image") else None
    if image_path and image_path.is_file():
        file = discord.File(image_path, filename=image_path.name)
        embed.set_image(url=f"attachment://{image_path.name}")
        await interaction.response.send_message(embed=embed, file=file)
    else:
        await interaction.response.send_message(embed=embed)


@bot.tree.command(name="collection", description="View your card collection or another member's.")
@app_commands.describe(member="Whose collection should be shown? Leave blank for your own.")
async def collection(interaction: discord.Interaction, member: discord.Member | None = None):
    target = member or interaction.user
    with connect_db() as con:
        rows = con.execute("""SELECT c.name,c.rarity,x.quantity FROM collection x
            JOIN cards c ON c.card_id=x.card_id WHERE x.user_id=? ORDER BY c.name COLLATE NOCASE""",
            (str(target.id),)).fetchall()
    if not rows:
        await interaction.response.send_message(f"{target.display_name} has not caught any cards yet.")
        return
    total = sum(r[2] for r in rows)
    lines = [f"**{name}** · {rarity} · ×{qty}" for name, rarity, qty in rows]
    embed = discord.Embed(title=f"🎴 {target.display_name}'s collection", description="\n".join(lines)[:4000], color=discord.Color.blurple())
    embed.set_footer(text=f"{len(rows)} unique cards • {total} total copies")
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="cards", description="Browse all cards available to catch.")
async def cards(interaction: discord.Interaction):
    all_cards = get_cards()
    if not all_cards:
        await interaction.response.send_message("The card catalog is empty.", ephemeral=True)
        return
    lines = [f"**{c['name']}** — {c['rarity']} (`{c['id']}`)" for c in all_cards]
    embed = discord.Embed(title="📚 Card catalog", description="\n".join(lines)[:4000], color=discord.Color.blurple())
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(name="addcard", description="Add a new card to the catalog (server admins only).")
@app_commands.checks.has_permissions(manage_guild=True)
@app_commands.describe(name="Card name", rarity="Common, Rare, Epic, or Legendary", image_url="Optional direct image URL")
@app_commands.choices(rarity=[
    app_commands.Choice(name="Common", value="Common"),
    app_commands.Choice(name="Rare", value="Rare"),
    app_commands.Choice(name="Epic", value="Epic"),
    app_commands.Choice(name="Legendary", value="Legendary"),
])
async def addcard(interaction: discord.Interaction, name: str, rarity: app_commands.Choice[str], image_url: str | None = None):
    clean_name = name.strip()
    if not clean_name or len(clean_name) > 80:
        await interaction.response.send_message("Card names must be 1–80 characters.", ephemeral=True)
        return
    card_id = "custom_" + str(abs(hash((clean_name.lower(), time.time_ns()))))
    with connect_db() as con:
        con.execute("INSERT INTO cards(card_id,name,rarity,image) VALUES(?,?,?,?)",
                    (card_id, clean_name, rarity.value, image_url.strip() if image_url else None))
    await interaction.response.send_message(f"Added **{clean_name}** ({rarity.value}) to the card catalog. ID: `{card_id}`")


@addcard.error
async def addcard_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        await interaction.response.send_message("You need the **Manage Server** permission to add cards.", ephemeral=True)
    else:
        await interaction.response.send_message("I couldn't add that card. Check the details and try again.", ephemeral=True)


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("Missing DISCORD_TOKEN. Copy .env.example to .env and add your bot token.")
    load_catalog()
    bot.run(TOKEN)
